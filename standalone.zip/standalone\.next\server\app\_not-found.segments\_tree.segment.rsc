:HL["/_next/static/chunks/34h7twjztmeg_.css","style"]
0:{"tree":{"name":"","param":null,"prefetchHints":4176,"slots":{"children":{"name":"/_not-found","param":null,"prefetchHints":4192,"slots":{"children":{"name":"__PAGE__","param":null,"prefetchHints":4256,"slots":null}}}}},"staleTime":300,"buildId":"V7q1JCqYR0gOMIcUgasyC"}
